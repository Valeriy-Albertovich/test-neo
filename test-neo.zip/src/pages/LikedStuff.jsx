import React from 'react'

export default function LikedStuff() {
  return (
    <div>LikedStuff</div>
  )
}
