export const products = [
  {
    id: 1,
    title: "Apple BYZ S852I",
    price: 2999,
    description: "best heaphones ever",
    category: "wired headphones",
    image: "img/hp-6.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 2,
    title: "Apple EarPods 1",
    price: 2999,
    description: "best heaphones ever",
    category: "wired headphones",
    image: "img/hp-1.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 3,
    title: "Apple EarPods 2",
    price: 2999,
    description: "best heaphones ever",
    category: "wired headphones",
    image: "img/hp-2.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 4,
    title: "Apple EarPods 3",
    price: 2999,
    description: "best heaphones ever",
    category: "wired headphones",
    image: "img/hp-1.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 5,
    title: "Apple EarPods 4",
    price: 2999,
    description: "best heaphones ever",
    category: "wired headphones",
    image: "img/hp-1.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 6,
    title: "Apple AirPods 1",
    price: 2999,
    description: "best heaphones ever",
    category: "wireless headphones",
    image: "img/hp-3.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 7,
    title: "Apple AirPods 2",
    price: 2999,
    description: "best heaphones ever",
    category: "wireless headphones",
    image: "img/hp-3.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 8,
    title: "GERLAX GH-04",
    price: 2999,
    description: "best heaphones ever",
    category: "wireless headphones",
    image: "img/hp-4.png",
    rating: 4.5,
    sale: 0
  }, 
  {
    id: 9,
    title: "BOROFONE BO4",
    price: 2999,
    description: "best heaphones ever",
    category: "wireless headphones",
    image: "img/hp-5.png",
    rating: 4.5,
    sale: 0
  }
]